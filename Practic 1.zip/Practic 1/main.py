"""Мне надоели какие-то синие черточки"""
print("Введите не больше 3-х чисел через пробел. Эти числа не должны быть больше 5")
def main():
    try:
        global NUM
        NUM = list(map(int, input().split(" ")))
        print(NUM)
    
    except ValueError:
        print("Вы ввели не число!")
        main()

main()
if len(NUM) > 3:
    print("Нужно ввести только 3 числа!")

i = 0
leng = len(NUM)
for i in range(0,leng):
    if NUM[i] > 5:
        print("Нужно ввести числа, не больше 5")
        main()

STR_NUM = map(str,NUM)
FILE = open("txt.txt", "a")
for index in STR_NUM:
    FILE.write(index + ' ')
FILE.write('\n')
FILE.close()
